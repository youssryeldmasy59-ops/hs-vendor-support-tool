/**
 * ⚡ Extension Popup Logic for HeroCare Auto-Pilot
 */

document.addEventListener('DOMContentLoaded', () => {
    const sleepToggle = document.getElementById('sleepModeToggle');
    const caseTitle = document.getElementById('caseTitle');
    const entOrder = document.getElementById('entOrder');
    const entStore = document.getElementById('entStore');
    const entAmount = document.getElementById('entAmount');
    const solvedCount = document.getElementById('solvedCount');
    const injectBtn = document.getElementById('injectBtn');
    const copyBtn = document.getElementById('copyBtn');

    let currentMacroText = '';

    // 1. Load initial storage
    chrome.storage.local.get(['hs_sleep_mode', 'hs_solved_count'], (res) => {
        if (res.hs_sleep_mode !== undefined) sleepToggle.checked = res.hs_sleep_mode;
        if (res.hs_solved_count !== undefined) solvedCount.innerText = String(res.hs_solved_count);
    });

    // 2. Query active tab
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (!tabs || !tabs[0]) return;
        const activeTab = tabs[0];

        chrome.tabs.sendMessage(activeTab.id, { action: 'GET_ANALYSIS' }, (response) => {
            if (chrome.runtime.lastError || !response || !response.analysis) {
                caseTitle.innerText = 'افتح تذكرة في HeroCare أو Operations Portal لرصدها لايف 📌';
                return;
            }

            const an = response.analysis;
            caseTitle.innerText = `${an.bestCase.case_title} (${an.confidence}%)`;

            const ent = an.entities || {};
            entOrder.innerText = ent.orderId || '-';
            entStore.innerText = ent.storeName || '-';
            entAmount.innerText = ent.amount ? `${ent.amount} ر.س` : '-';

            if (an.macros && an.macros.arMacro) {
                currentMacroText = an.macros.arMacro;
            }

            if (response.solvedTicketsCount !== undefined) {
                solvedCount.innerText = String(response.solvedTicketsCount);
            }
        });
    });

    // 3. Handle Sleep Mode Toggle
    sleepToggle.addEventListener('change', (e) => {
        const val = e.target.checked;
        chrome.storage.local.set({ hs_sleep_mode: val });
    });

    // 4. Handle Inject Button
    injectBtn.addEventListener('click', () => {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            if (!tabs || !tabs[0]) return;
            chrome.tabs.sendMessage(tabs[0].id, { action: 'INJECT_NOW' }, (res) => {
                if (res && res.success) {
                    injectBtn.innerText = '✅ تم الحقن بنجاح!';
                    setTimeout(() => injectBtn.innerText = '⚡ حقن الرد المعتمد في التذكرة', 2000);
                } else {
                    alert('⚠️ تأكد من فتح صندوق الرد داخل التذكرة في هيروكير أولاً.');
                }
            });
        });
    });

    // 5. Handle Copy Button
    copyBtn.addEventListener('click', () => {
        if (currentMacroText) {
            navigator.clipboard.writeText(currentMacroText).then(() => {
                copyBtn.innerText = '📋 تم النسخ!';
                setTimeout(() => copyBtn.innerText = '📋 نسخ الرد للحافظة', 2000);
            });
        } else {
            alert('⚠️ لا يوجد نص ماكرو جاهز للنسخ بعد.');
        }
    });
});
