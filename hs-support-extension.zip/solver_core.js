/**
 * ⚡ Hungerstation Autonomous AI Solver Core (v2026)
 * Embedded in Chrome Extension for HeroCare & Operations Portal
 */

(function (window) {
    'use strict';

    // 1. Text Normalizer
    function normalizeArabic(text) {
        if (!text) return '';
        let s = String(text).toLowerCase();
        s = s.replace(/[ًٌٍَُِّْـ]/g, ''); // Remove tashkeel & tatweel
        s = s.replace(/[أإآ]/g, 'ا');      // Normalize alef
        s = s.replace(/ة/g, 'ه');          // Normalize teh marbuta
        s = s.replace(/ى/g, 'ي');          // Normalize alef maqsura
        s = s.replace(/[^\w\s\u0600-\u06FF]/gi, ' ');
        return s.replace(/\s+/g, ' ').trim();
    }

    // 2. Entity Extractor
    function extractTicketEntities(rawText) {
        if (!rawText) return {};
        const entities = {
            orderId: null,
            storeName: null,
            amount: null,
            riderName: null,
            customerName: null,
            iban: null,
            branchId: null
        };

        // 1. Order ID
        const orderMatch = rawText.match(/(?:طلب(?:كم)?|الطلب|أوردر|اوردر|Order|order)\s*(?:رقم|no\.?|#)?\s*[:#-]?\s*(\d{5,12})/i) ||
                           rawText.match(/#(\d{5,12})\b/) ||
                           rawText.match(/\b(1\d{7,9}|2\d{7,9}|3\d{7,9}|4\d{7,9}|5\d{7,9})\b/);
        if (orderMatch) entities.orderId = orderMatch[1];

        // 2. Amount / SAR
        const amtMatch = rawText.match(/(\d+(?:\.\d+)?)\s*(?:ريال|SAR|SR|ر\.س)/i) ||
                         rawText.match(/(?:مبلغ|قيمة|قيمه|تكلفة|تكلفه|amount|total)\s*[:\-]?\s*(\d+(?:\.\d+)?)/i);
        if (amtMatch) entities.amount = amtMatch[1];

        // 3. Store Name
        const storeMatch = rawText.match(/(?:اسم\s*(?:الشريك|المتجر|المطعم|الفرع)|Partner\s*Name|Store\s*Name|Restaurant)\s*[:\-]\s*([^\n\r,،]+)/i) ||
                           rawText.match(/(?:متجر|مطعم|فرع)\s*[:\-]?\s*([\u0600-\u06FFA-Za-z0-9\s]{2,30}?)(?=[\n\r,،\.]|رقم|ID|هاتف|$)/i);
        if (storeMatch && storeMatch[1].trim().length >= 2) {
            const sName = storeMatch[1].trim();
            if (!/^\d+$/.test(sName) && !['رقم', 'جديد', 'الخاص', 'المعتمد', 'ID'].includes(sName)) {
                entities.storeName = sName;
            }
        }

        
        // 3.1 Banner / Store Name from phrases like "تعديل بنر متجر باب شرقي" or "بنر باب شرقي"
        const bannerStoreMatch = rawText.match(/(?:متجر|مطعم|فرع|بنر)\s+([؀-ۿA-Za-z0-9\s]{2,25}?)(?=\s+(?:للبنر|الجديد|في|على|رقم|ID|هاتف|$|
|،))/i);
        if (bannerStoreMatch && bannerStoreMatch[1].trim().length >= 2) {
            const candidate = bannerStoreMatch[1].trim();
            if (!entities.storeName || entities.storeName === 'المتجر المعتمد') {
                entities.storeName = candidate;
            }
        }

        // 4. Rider / Driver Name
        const riderMatch = rawText.match(/(?:مندوب|سائق|سواق|رايدر|driver|rider|courier)\s*(?:الطلب|اسمه|اسم|هو)?\s*[:\-]?\s*([\u0600-\u06FFA-Za-z\s]{2,25}?)(?=[\n\r,،\.]|رقم|جوال|$)/i);
        if (riderMatch && riderMatch[1].trim().length >= 2) {
            entities.riderName = riderMatch[1].trim();
        }

        // 5. IBAN
        const ibanMatch = rawText.match(/\b(SA\d{22})\b/i);
        if (ibanMatch) entities.iban = ibanMatch[1].toUpperCase();

        return entities;
    }

    // 3. High-Velocity Inbound Intent Map (with Egyptian & Gulf Slang)
    const INBOUND_INTENT_MAP = [
        {
            keys: ['تعديل بنر', 'تغيير البنر', 'بنر المتجر', 'بنر باب شرقي', 'صورة الغلاف', 'تعديل بنر متجر', 'update banner', 'change banner', 'listing image', 'cover photo', 'رابط البنر', 'drive.google.com/file', 'تعديل بنر متجر باب شرقي'],
            id: 43
        },
        {
            keys: ['تعديل الشعار', 'تغيير الشعار', 'شعار المتجر', 'تحديث اللوجو', 'change logo', 'update logo', 'رفع الشعار'],
            id: 44
        },
        {
            keys: ['تعديل صورة المنتج', 'رفع صورة الوجبة', 'تحديث صور الاصناف', 'صورة البرجر', 'update product photo'],
            id: 42
        },

        {
            keys: ['السواق هرب', 'السواق مشي ومحاسبش', 'الرايدر اخد الاوردر وطار', 'المندوب استلم بدون دفع', 'السائق هرب وما دفع', 'الرايدر مشي من غير ما يدفع', 'اخذ الطلب وهرب', 'driver left without paying', 'rider took food without payment'],
            id: 10
        },
        {
            keys: ['العميل كنسل بعد ما جهزنا', 'الزبون لغى الطلب بعد ما استوى', 'العميل رفض يستلم', 'الزبون ما استلم والوجبة جهزت', 'طلب ملغي بعد التجهيز ونبي تعويض', 'العميل كنسل بعد التجهيز', 'الوجبة اتجهزت والطلب اتكنسل', 'customer cancelled after preparation', 'food prepared but order cancelled'],
            id: 11
        },
        {
            keys: ['التابلت طافي', 'الجهاز باظ', 'الشاشة مكسورة', 'التابلت مش راضي يفتح', 'الجهاز خربان ومعلق', 'شاشة التابلت سوداء', 'التابلت ما يشتغل', 'نبي استبدال تابلت', 'بديل للتابلت', 'tablet broken', 'tablet not turning on', 'tablet screen cracked'],
            id: 31
        },
        {
            keys: ['الفلوس منزلتش', 'فين المستحقات', 'تأخر التحويل المالي', 'ما نزل رصيد المتجر', 'الفاتورة ناقصة فلوس', 'فين ارباح الاسبوع', 'مستحقات المطعم متأخرة', 'payment delayed', 'transfer not received', 'missing payout'],
            id: 41
        },
        {
            keys: ['تغيير الايبان', 'عايزين نغير الايبان', 'تعديل الحساب البنكي', 'الحساب البنكي مقفول', 'تحديث رقم الايبان للمتجر', 'change iban', 'update bank account'],
            id: 43
        },
        {
            keys: ['خصمتم مني ليه', 'ليه مخصوم من الفاتورة', 'خصم تعويض بالخطأ', 'نسبة الخصم عالية', 'اعتراض على خصم الفاتورة', 'ليه التعويض مخصوم علينا', 'dispute deduction', 'wrong compensation deduction'],
            id: 45
        },
        {
            keys: ['المتجر يظهر مغلق في تطبيق هنقرستيشن', 'المحل مقفل في التطبيق', 'الفرع مغلق في البرنامج نبي نخليه مفتوح', 'المحل مش ظاهر في التطبيق ومغلق عند العملاء', 'ليه المتجر مغلق عند الزبائن', 'الفرع شغال والطابعة متصلة لكن في التطبيق مكتوب مغلق', 'متى يفتح الفرع بالتطبيق', 'تعديل حالة المتجر من مغلق الى مفتوح', 'فتح الفرع في هنقرستيشن', 'المتجر غير متاح للطلب', 'store appears closed in app'],
            id: 18
        },
        {
            keys: ['تأخر المندوب اكثر من 15 دقيقة', 'السواق متأخر والوجبة بردت', 'المندوب لم يصل لاستلام الطلب', 'تأخير السائق', 'rider delayed more than 15 min', 'driver delayed pickup'],
            id: 1
        },
        {
            keys: ['تعديل اسعار المنيو', 'تحديث قائمة الطعام', 'اضافة صنف جديد للمنيو', 'حذف وجبة من التطبيق', 'update menu prices', 'add item to menu', 'modify menu'],
            id: 20
        }
    ];

    // 4. Case Matcher Engine
    function matchBestCase(rawText) {
        const kb = window.HS_OFFICIAL_KB || [];
        if (!kb.length) return null;

        const normInput = normalizeArabic(rawText);

        // A. Match via Inbound Intent Map first (Highest Precision)
        for (const intent of INBOUND_INTENT_MAP) {
            for (const key of intent.keys) {
                if (normInput.includes(normalizeArabic(key))) {
                    const matchedCase = kb.find(c => c.id == intent.id);
                    if (matchedCase) {
                        return {
                            bestCase: matchedCase,
                            confidenceScore: 98,
                            matchSource: 'EXACT_INTENT'
                        };
                    }
                }
            }
        }

        // B. Fuzzy Scoring across 102 cases
        let bestMatch = null;
        let highestScore = 0;

        const inputWords = normInput.split(/\s+/).filter(w => w.length > 2);

        kb.forEach(c => {
            let score = 0;
            const titleNorm = normalizeArabic(c.case_title || '');
            const procNorm = normalizeArabic(c.procedure_arabic || '');
            const contentNorm = normalizeArabic(c.full_content || '');

            inputWords.forEach(word => {
                if (titleNorm.includes(word)) score += 15;
                if (procNorm.includes(word)) score += 8;
                if (contentNorm.includes(word)) score += 3;
            });

            if (score > highestScore) {
                highestScore = score;
                bestMatch = c;
            }
        });

        const confidence = Math.min(95, Math.max(50, Math.round((highestScore / 60) * 100)));

        return {
            bestCase: bestMatch || kb[0],
            confidenceScore: confidence,
            matchSource: 'FUZZY_HEURISTIC'
        };
    }

    // 5. Macro Synthesis & Variable Interpolation
    function synthesizeMacros(c, entities, agentName = 'عمر') {
        const store = entities.storeName || 'شريكنا العزيز';
        const orderId = entities.orderId ? `#${entities.orderId}` : 'الطلب';
        const amount = entities.amount ? `${entities.amount} ريال` : '';
        const rider = entities.riderName || 'المندوب';

        let arProc = c.procedure_arabic || 'شكراً لتواصلكم مع فريق دعم شركاء هنقرستيشن.';
        let enProc = c.procedure_english || 'Thank you for reaching out to Hungerstation Vendor Support.';

        // Replace placeholders safely
        arProc = arProc.replace(/\[(?:اسم المتجر|اسم الشريك|المتجر)\]/g, store)
                       .replace(/\[(?:رقم الطلب|رقم الأوردر|الطلب)\]/g, orderId)
                       .replace(/\[(?:المبلغ|قيمة الطلب)\]/g, amount || 'المبلغ المحدد')
                       .replace(/\[(?:اسم الموظف|الموظف|الاسم)\]/g, agentName)
                       .replace(/\[(?:اسم السائق|السائق|الرايدر)\]/g, rider);

        enProc = enProc.replace(/\[(?:Store Name|Partner Name|Store)\]/gi, store)
                       .replace(/\[(?:Order ID|Order Number|Order)\]/gi, orderId)
                       .replace(/\[(?:Amount|Price)\]/gi, amount || 'the specified amount')
                       .replace(/\[(?:Agent Name|Agent)\]/gi, agentName)
                       .replace(/\[(?:Driver Name|Driver|Rider)\]/gi, rider);

        // Build full formatted macro
        const fullAr = `شريكنا العزيز (${store})،\n\nشكراً لتواصلكم مع فريق دعم شركاء هنقرستيشن بخصوص ${orderId}.\n\n${arProc}\n\nنحن هنا دائماً لخدمتكم ودعم نجاح أعمالكم.\n\nمع الشكر والتقدير لتعاونكم،\n${agentName}\nفريق دعم شركاء هنقرستيشن`;

        const fullEn = `Dear Partner (${store}),\n\nThank you for contacting Hungerstation Vendor Support regarding ${orderId}.\n\n${enProc}\n\nWe are always here to support your operations and success.\n\nBest regards,\n${agentName}\nHungerstation Partner Support`;

        return {
            arMacro: fullAr,
            enMacro: fullEn,
            caseId: c.id,
            caseTitle: c.case_title,
            sopSteps: c.procedure_arabic || ''
        };
    }

    // Public API
    window.HSSolverCore = {
        extractTicketEntities,
        matchBestCase,
        synthesizeMacros,
        normalizeArabic
    };

})(window);
