/**
 * ⚡ Background Service Worker for Hungerstation HeroCare Auto-Pilot
 */

chrome.runtime.onInstalled.addListener(() => {
    console.log('[HS Auto-Pilot] Extension installed successfully.');
    chrome.storage.local.set({
        hs_sleep_mode: false,
        hs_solved_count: 0
    });
});

// Update badge with solved tickets count
chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes.hs_solved_count) {
        const count = changes.hs_solved_count.newValue || 0;
        chrome.action.setBadgeText({ text: count > 0 ? String(count) : '' });
        chrome.action.setBadgeBackgroundColor({ color: '#10B981' });
    }
});
