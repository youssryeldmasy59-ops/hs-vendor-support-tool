/**
 * ⚡ Hungerstation HeroCare & Operations Portal Auto-Pilot Content Script (v2026)
 */

(function () {
    'use strict';

    let isSleepModeActive = false;
    let isHudMinimized = false;
    let currentTicketAnalysis = null;
    let solvedTicketsCount = 0;
    let lastProcessedText = '';

    // Load saved settings
    chrome.storage.local.get(['hs_sleep_mode', 'hs_solved_count'], (res) => {
        if (res.hs_sleep_mode !== undefined) isSleepModeActive = res.hs_sleep_mode;
        if (res.hs_solved_count !== undefined) solvedTicketsCount = res.hs_solved_count;
        initAutopilotHud();
    });

    // 1. Locate Ticket Text in HeroCare / Zendesk / Operations Portal
    function findTicketText() {
        // HeroCare / Salesforce selectors
        const sfSelectors = [
            '.feeditemcommentbody',
            '.cuf-feedItemText',
            '.slds-feed__item-comments',
            '.email-body',
            '.slds-rich-text-editor__output',
            '[data-aura-class="forceChatterFeedInnerItem"]',
            '.case-description',
            '.slds-card__body'
        ];

        for (const sel of sfSelectors) {
            const el = document.querySelector(sel);
            if (el && el.innerText && el.innerText.trim().length > 15) {
                return el.innerText.trim();
            }
        }

        // Zendesk selectors
        const zdSelectors = [
            '.comment .body',
            'div[data-test-id="ticket-pane-subject"]',
            '.ember-view.workspace .comment',
            '.ticket-body',
            'section.ticket-panes'
        ];

        for (const sel of zdSelectors) {
            const el = document.querySelector(sel);
            if (el && el.innerText && el.innerText.trim().length > 15) {
                return el.innerText.trim();
            }
        }

        // Generic fallback: grab visible body text within main content area
        const mainArea = document.querySelector('main') || document.querySelector('#content') || document.body;
        if (mainArea) {
            const fullText = mainArea.innerText || '';
            const match = fullText.match(/(?:الموضوع|الطلب|طلب رقم|Order|مشكلة|العميل|المندوب|المتجر)[\s\S]{20,800}/i);
            if (match) return match[0];
        }

        return '';
    }

    // 2. Locate Active Composer / Textarea in HeroCare / Zendesk
    function findComposerElement() {
        const composers = [
            // Zendesk Froala
            '.fr-element.fr-view',
            'div[aria-label="Composer body"]',
            'div[data-test-id="omnichannel-scratchpad"]',
            // Salesforce / HeroCare
            'div[contenteditable="true"]',
            '.cke_editable',
            'textarea.cuf-feedItemText',
            'lightning-textarea textarea',
            'textarea[placeholder*="رد"]',
            'textarea[placeholder*="Reply"]',
            'textarea.comment_input',
            'textarea'
        ];

        for (const sel of composers) {
            const el = document.querySelector(sel);
            // Ensure element is visible and not hidden
            if (el && el.offsetParent !== null) {
                return el;
            }
        }
        return null;
    }

    // 3. Inject Macro into Composer safely across frameworks
    function injectMacroIntoComposer(macroText) {
        const composer = findComposerElement();
        if (!composer) {
            console.warn('[HS Auto-Pilot] No composer element found in DOM.');
            return false;
        }

        composer.focus();

        if (composer.isContentEditable || composer.getAttribute('contenteditable') === 'true') {
            // Replace line breaks with paragraphs/br for rich editors
            const formattedHtml = macroText.split('\n\n').map(p => `<p>${p.replace(/\n/g, '<br>')}</p>`).join('');
            composer.innerHTML = formattedHtml;
        } else {
            composer.value = macroText;
        }

        // Trigger input, change, and keyup events for React / Angular / Ember
        ['input', 'change', 'keydown', 'keyup'].forEach(eventType => {
            const event = new Event(eventType, { bubbles: true, cancelable: true });
            composer.dispatchEvent(event);
        });

        return true;
    }

    // 4. Analyze Current Ticket & Update HUD
    function analyzeCurrentTicket() {
        const text = findTicketText();
        if (!text || text.length < 10) return;
        if (text === lastProcessedText) return;

        lastProcessedText = text;

        if (!window.HSSolverCore) return;

        const entities = window.HSSolverCore.extractTicketEntities(text);
        const match = window.HSSolverCore.matchBestCase(text);
        if (!match) return;

        const macros = window.HSSolverCore.synthesizeMacros(match.bestCase, entities, 'عمر');

        currentTicketAnalysis = {
            text,
            entities,
            bestCase: match.bestCase,
            confidence: match.confidenceScore,
            macros
        };

        updateHudDisplay(currentTicketAnalysis);

        // 🌙 Autonomous Sleep Mode Handling
        if (isSleepModeActive && match.confidenceScore >= 85) {
            const success = injectMacroIntoComposer(macros.arMacro);
            if (success) {
                solvedTicketsCount++;
                chrome.storage.local.set({ hs_solved_count: solvedTicketsCount });
                updateSolvedCounterDisplay();

                // Optional submit trigger if configured
                console.log(`[HS Sleep Mode] 🌙 Successfully solved ticket autonomously: ${match.bestCase.case_title}`);
            }
        }
    }

    // 5. Build and Inject Floating HUD UI
    function initAutopilotHud() {
        if (document.getElementById('hs-autopilot-hud')) return;

        const container = document.createElement('div');
        container.id = 'hs-autopilot-hud';

        container.innerHTML = `
            <div class="hs-hud-capsule" id="hsHudCapsule">
                <div class="hs-hud-header">
                    <div class="hs-hud-brand">
                        <span class="hs-hud-pulse"></span>
                        <span>HS Auto-Pilot ⚡</span>
                        <span style="font-size: 0.65rem; background: #F59E0B; color: #000; padding: 1px 6px; border-radius: 4px; font-weight: 800;">عمر ⭐</span>
                    </div>
                    <div style="display: flex; gap: 4px;">
                        <button class="hs-hud-btn-mini" id="hsHudMinimizeBtn" title="تصغير">_</button>
                    </div>
                </div>

                <div class="hs-hud-body">
                    <div class="hs-hud-case-card" id="hsHudCaseCard">
                        <div class="hs-hud-case-title" id="hsHudCaseTitle">جاري استكشاف التذكرة... 🔍</div>
                        <div class="hs-hud-pills" id="hsHudPills">
                            <span class="hs-hud-pill">📦 طلب: <strong>-</strong></span>
                            <span class="hs-hud-pill">🏪 متجر: <strong>-</strong></span>
                            <span class="hs-hud-pill">💰 مبلغ: <strong>-</strong></span>
                        </div>
                    </div>

                    <button class="hs-hud-btn-inject" id="hsHudInjectBtn">
                        <span>⚡ حقن الرد المعتمد فوراً</span>
                    </button>

                    <div class="hs-hud-sleep-toggle">
                        <div style="display: flex; align-items: center; gap: 6px;">
                            <span>🌙 وضع النوم والحل الذاتي</span>
                            <span id="hsHudSolvedBadge" style="background: rgba(139,92,246,0.25); color: #C4B5FD; padding: 1px 5px; border-radius: 4px; font-size: 0.65rem;">${solvedTicketsCount} تم</span>
                        </div>
                        <label class="hs-hud-switch">
                            <input type="checkbox" id="hsHudSleepCheckbox" ${isSleepModeActive ? 'checked' : ''}>
                            <span class="hs-hud-slider"></span>
                        </label>
                    </div>
                </div>
            </div>
        `;

        document.body.appendChild(container);

        // Attach listeners
        document.getElementById('hsHudMinimizeBtn').addEventListener('click', toggleHudMinimize);
        document.getElementById('hsHudInjectBtn').addEventListener('click', () => {
            if (currentTicketAnalysis && currentTicketAnalysis.macros) {
                const ok = injectMacroIntoComposer(currentTicketAnalysis.macros.arMacro);
                if (ok) {
                    solvedTicketsCount++;
                    chrome.storage.local.set({ hs_solved_count: solvedTicketsCount });
                    updateSolvedCounterDisplay();
                    alert('✅ تم حقن الماكرو المعتمد بنجاح في صندوق الرد!');
                } else {
                    alert('⚠️ لم يتم العثور على صندوق الرد. يرجى فتح التذكرة والضغط داخل صندوق الرد أولاً.');
                }
            } else {
                alert('⚠️ لم يتم رصد بيانات تذكرة واضحة في الصفحة بعد.');
            }
        });

        document.getElementById('hsHudSleepCheckbox').addEventListener('change', (e) => {
            isSleepModeActive = e.target.checked;
            chrome.storage.local.set({ hs_sleep_mode: isSleepModeActive });
            if (isSleepModeActive) {
                alert('🌙 تم تفعيل وضع النوم الذاتي! الأداة ستقوم بحل التذاكر التي تتطابق بدقة عالية (85%+) تلقائياً أثناء نومك.');
            }
        });

        // Periodic Check (every 4 seconds)
        setInterval(analyzeCurrentTicket, 4000);
        analyzeCurrentTicket();
    }

    function toggleHudMinimize() {
        const cap = document.getElementById('hsHudCapsule');
        isHudMinimized = !isHudMinimized;
        if (isHudMinimized) {
            cap.classList.add('minimized');
            cap.innerHTML = '<span style="font-size: 1.4rem;">⚡</span>';
        } else {
            cap.classList.remove('minimized');
            initAutopilotHud();
        }
    }

    function updateHudDisplay(analysis) {
        const titleEl = document.getElementById('hsHudCaseTitle');
        const pillsEl = document.getElementById('hsHudPills');
        if (!titleEl || !pillsEl) return;

        titleEl.innerHTML = `الحالة: ${analysis.bestCase.case_title} <span style="color: #34D399; font-size: 0.72rem;">(${analysis.confidence}%)</span>`;

        const ent = analysis.entities || {};
        pillsEl.innerHTML = `
            <span class="hs-hud-pill">📦 طلب: <strong>${ent.orderId || '-'}</strong></span>
            <span class="hs-hud-pill">🏪 متجر: <strong>${ent.storeName || '-'}</strong></span>
            <span class="hs-hud-pill">💰 مبلغ: <strong>${ent.amount ? ent.amount + ' ريال' : '-'}</strong></span>
            ${ent.riderName ? `<span class="hs-hud-pill">🛵 رايدر: <strong>${ent.riderName}</strong></span>` : ''}
        `;
    }

    function updateSolvedCounterDisplay() {
        const badge = document.getElementById('hsHudSolvedBadge');
        if (badge) badge.innerText = `${solvedTicketsCount} تم`;
    }

    // Listen to messages from popup
    chrome.runtime.onMessage.addListener((req, sender, sendResponse) => {
        if (req.action === 'GET_ANALYSIS') {
            sendResponse({ analysis: currentTicketAnalysis, isSleepModeActive, solvedTicketsCount });
        } else if (req.action === 'INJECT_NOW') {
            if (currentTicketAnalysis && currentTicketAnalysis.macros) {
                const ok = injectMacroIntoComposer(currentTicketAnalysis.macros.arMacro);
                sendResponse({ success: ok });
            } else {
                sendResponse({ success: false, reason: 'NO_TICKET' });
            }
        }
        return true;
    });

})();
